
    <?php
    echo "<footer>
           &copy; Eunice De Grace Fmukam Ngadjou <br>
             Last Modified:
                <script > document.write(document.lastModified) </script>          
    </footer>";
    ?>
